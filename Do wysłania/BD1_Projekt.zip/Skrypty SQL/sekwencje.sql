create sequence "Rola_osoby_id_rola_osoby_seq";

alter sequence "Rola_osoby_id_rola_osoby_seq" owner to npbkqkcz;

create sequence "Ocena_id_ocena_seq";

alter sequence "Ocena_id_ocena_seq" owner to npbkqkcz;


