create function dodaj() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE 'Nowa ocena: %', NEW.ocena;
    IF NEW.ocena = 1 THEN
        UPDATE "Oceny_filmow" set ocena_1 = ocena_1 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 2 THEN
        UPDATE "Oceny_filmow" set ocena_2 = ocena_2 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 3 THEN
        UPDATE "Oceny_filmow" set ocena_3 = ocena_3 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 4 THEN
        UPDATE "Oceny_filmow" set ocena_4 = ocena_4 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 5 THEN
        UPDATE "Oceny_filmow" set ocena_5 = ocena_5 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 6 THEN
        UPDATE "Oceny_filmow" set ocena_6 = ocena_6 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 7 THEN
        UPDATE "Oceny_filmow" set ocena_7 = ocena_7 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 8 THEN
        UPDATE "Oceny_filmow" set ocena_8 = ocena_8 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 9 THEN
        UPDATE "Oceny_filmow" set ocena_9 = ocena_9 + 1 where id_film = NEW.id_film;
    ELSIF NEW.ocena = 10 THEN
        UPDATE "Oceny_filmow" set ocena_10 = ocena_10 + 1 where id_film = NEW.id_film;
    END IF;

    RETURN NEW;
END;
$$;

alter function dodaj() owner to npbkqkcz;

