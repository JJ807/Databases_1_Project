create function policzsredniaocen() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.liczba_ocen = NEW.ocena_10 + NEW.ocena_9 + NEW.ocena_8 + NEW.ocena_7 + NEW.ocena_6 +
                      NEW.ocena_5 + NEW.ocena_4 + NEW.ocena_3 + NEW.ocena_2 +
                      NEW.ocena_1;
    IF NEW.liczba_ocen = 0 THEN
        NEW.liczba_ocen = 1;
    END IF;

    NEW.srednia :=
            (SELECT (NEW.ocena_10 * 10 + NEW.ocena_9 * 9 + NEW.ocena_8 * 8 + NEW.ocena_7 * 7 +
                     NEW.ocena_6 * 6 +
                     NEW.ocena_5 * 5 + NEW.ocena_4 * 4 + NEW.ocena_3 * 3 + NEW.ocena_2 * 2 +
                     NEW.ocena_1 * 1) /
                    CAST(NEW.liczba_ocen AS NUMERIC(4, 1))
             FROM "Oceny_filmow"
             where id_film = NEW.id_film);

    RAISE NOTICE 'Srednia nowa: %, Srednia stara: %, id_film: %', NEW.srednia, OLD.srednia, NEW.id_film;
    RAISE NOTICE 'Liczba ocen nowa: %, Liczba ocen stara: %, id_film: %', NEW.liczba_ocen, OLD.liczba_ocen, NEW.id_film;
    RETURN NEW;
END ;
$$;

alter function policzsredniaocen() owner to npbkqkcz;

