create view osoba_info
            (id_osoba, imie_i_nazwisko, data_narodzin, data_smierci, bio, rola, tytul, rok,
             postac_z_filmu) as
SELECT o.id_osoba,
       o.imie_i_nazwisko,
       o.data_narodzin,
       o.data_smierci,
       o.bio,
       r.rola,
       f.tytul,
       f.rok,
       ro.postac_z_filmu
FROM "Osoba" o
         JOIN "Rola_osoby" ro ON o.id_osoba::text = ro.id_osoba::text
         JOIN "Rola" r ON r.id_rola = ro.id_rola
         JOIN "Film" f ON ro.id_film::text = f.id_film::text
ORDER BY o.imie_i_nazwisko;

alter table osoba_info
    owner to npbkqkcz;

