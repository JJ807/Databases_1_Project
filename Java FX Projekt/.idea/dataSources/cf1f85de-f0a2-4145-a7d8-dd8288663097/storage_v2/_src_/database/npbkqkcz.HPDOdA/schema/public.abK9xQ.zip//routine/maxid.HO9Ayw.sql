create function maxid(tablename character varying, idname character varying) returns integer
    language plpgsql
as
$$
    -- otwarcie bloku programowego
BEGIN
    Select max(idName) from tableName ;
END;
$$;

alter function maxid(varchar, varchar) owner to npbkqkcz;

